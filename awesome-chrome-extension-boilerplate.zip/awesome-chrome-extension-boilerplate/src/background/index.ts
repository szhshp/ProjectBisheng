console.log('This is background page!');

export default null;
