import { hot } from 'react-hot-loader/root';
import React from 'react';

import './App.scss';

const App = () => {
  return (
    <div className="app">
      <h1 className="title">options page</h1>
    </div>
  );
};

export default hot(App);
