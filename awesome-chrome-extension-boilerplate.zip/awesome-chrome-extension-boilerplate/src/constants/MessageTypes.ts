const MESSAGE = {
  FORMAT: 'format',
};

export default MESSAGE;
